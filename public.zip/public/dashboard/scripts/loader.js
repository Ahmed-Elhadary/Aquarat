$(window).on('load', function () {
    $('.dashboard-loader').fadeOut(500);
});
