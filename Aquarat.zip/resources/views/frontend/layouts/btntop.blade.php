<button class="scroltop style2 radius" type="button"><i class="fa fa-arrow-up"></i></button>
   <!-- social icon -->

   <div class="social-icon-pages" onclick="toggleBtn()">
    <div class="action">
        <i class="fa fa-plus" id="add"></i>
        <i class="fa fa-times" id="remove" style="display: none"></i>
    </div>

    <div class="btns">
        <a href="#" class="btn" style="background: #3b5999"><i class="fa fa-facebook"></i></a>
        <a href="#" class="btn" style="background: #55acee"><i class="fa fa-twitter"></i></a>
        <a href="#" class="btn" style="background: #0a66c2"><i class="fa fa-linkedin"></i></a>
        <a href="#" class="btn" style="background:#e4405f"><i class="fa fa-instagram"></i></a>
    </div>
</div>
