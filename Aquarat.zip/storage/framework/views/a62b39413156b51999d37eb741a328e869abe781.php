 

 <?php $__env->startSection('content'); ?>
 <br><br>
   <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">

              <!-- /.card -->

              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">contactus</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>E-Mail</th>
                        <th>Message</th>
                        <th>Action</th>

                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cont->name); ?></td>
                            <td><?php echo e($cont->phone); ?></td>
                            <td><?php echo e($cont->email); ?></td>
                            <td><?php echo e($cont->message); ?></td>

                           <td>
                            <form action="<?php echo e(route('contactus.destroy',$cont)); ?>" method="post" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                      <button  class="delete_ancor btn btn-danger">
                        <i class="fa fa-trash"></i>
                      </button>
                           </td>

                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>

 <?php $__env->stopSection(); ?>
 <?php $__env->startPush('custom-scripts'); ?>
 <script>
     $(function () {
       $("#example1").DataTable({
         "responsive": true, "lengthChange": true, "autoWidth": true,
         "lengthMenu": [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
         "buttons": ["copy", "csv", "excel", "print", "colvis"],
         columnDefs: [
                         {
                         targets: "hiddenCols", visible: false
                     }
                     ],
       }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
     });
     </script>
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Aquarat\resources\views/dashboard/pages/contactus.blade.php ENDPATH**/ ?>