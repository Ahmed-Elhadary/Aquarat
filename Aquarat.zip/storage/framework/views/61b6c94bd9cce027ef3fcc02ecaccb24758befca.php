

<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="page-title-heading">
                    <div>Edit Slider
                    </div>
                </div>
            </div>
            <div class="col-6 ">
                <div class="page-links-heading">
                      Edit Slider / <a href="<?php echo e(route('sliders.index')); ?>">Sliders</a> /
                       <a href="<?php echo e(route('dashboard.index')); ?>">Home</a>
                </div>
            </div>
        </div>
    </div>

      </div>
</div>
 <div class="app-main__inner">

          <div class="main-card mb-3 card ">

            <div class="card-body">
                <div class="page-title-icon">
                    <i class="pe-7s-photo-gallery">
                    </i>
                </div>
                <form class="needs-validation " novalidate action="<?php echo e(route('sliders.update',$slider->id)); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row ">
                        
                        <div class="col-md-12 mb-3 image">
                            <label>Image *</label>
                            <div class="input-group mb-3">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="image">
                                    <label class="custom-file-label" for="inputGroupFile02">Choose file</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12 mb-3">
                            <label >Arabic Description *</label>
                            <textarea type="text" class="form-control" name="ar_description"  maxlength="200"  placeholder="Arabic Discription"  required><?php echo e($slider->ar_description); ?></textarea>
                            maximum length of 200 characters
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        
                    </div>
                    <?php echo e(method_field('PUT')); ?>

                    <button class="btn btn-warning" type="submit">Update</button>
                </form>

                <script>
                    (function() {
                        'use strict';
                        window.addEventListener('load', function() {
                            var forms = document.getElementsByClassName('needs-validation');
                            var validation = Array.prototype.filter.call(forms, function(form) {
                                form.addEventListener('submit', function(event) {
                                    if (form.checkValidity() === false) {
                                        event.preventDefault();
                                        event.stopPropagation();
                                    }
                                    form.classList.add('was-validated');
                                }, false);
                            });
                        }, false);
                    })();
                </script>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $('input[name="type"]').on('click', function() {
            var type = $("input[name='type']:checked").val();
            console.log(type);
            if (type != '') {
                if (type == 0) {
                    $('.video').removeClass('d-none');
                    $('.image').addClass('d-none');

                } else if (type == 1) {
                    $('.image').removeClass('d-none');
                    $('.video').addClass('d-none');
                }

            }
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Aquarat\resources\views/dashboard/pages/editsliders.blade.php ENDPATH**/ ?>