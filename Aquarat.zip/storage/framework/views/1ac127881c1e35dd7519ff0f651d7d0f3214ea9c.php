<div class="app-sidebar sidebar-shadow">
    <div class="app-header__logo">
        <div class="logo-src"></div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                    data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button"
                class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">
                <li class="app-sidebar__heading">Dashboard</li>
                <li>
                    <a href="<?php echo e(route('dashboard.index')); ?>" class=" <?php echo e((request()->is('*dashboard/home')) ? 'mm-active' : ''); ?>">
                        <i class="metismenu-icon pe-7s-display2"></i>
                        Dashboard
                    </a>
                </li>
                <li class="app-sidebar__heading">Components</li>

                <li class="<?php echo e((request()->is('*dashboard/maincategory*') ||
                    request()->is('*dashboard/products*')) ? 'mm-active' : ''); ?>">
                    <a href="">
                        <i class="metismenu-icon pe-7s-box1"></i>
                        Our business
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul>
                        <li>
                            <a class="<?php echo e((request()->is('*dashboard/maincategory*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('maincategory.index')); ?>">
                                <i class="metismenu-icon"></i>
                                Main Category
                            </a>
                        </li>
                        <li>
                            <a class="<?php echo e((request()->is('*dashboard/products*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('products.index')); ?>">
                                <i class="metismenu-icon"></i>
                                Our business
                            </a>
                        </li>
                    </ul>
                </li>
                
                
                <li class="<?php echo e((request()->is('*dashboard/company_date*') ||
                    request()->is('*dashboard/aboutcompany*') || request()->is('*dashboard/companyservice*') ||
                    request()->is('*dashboard/achievements*') || request()->is('*dashboard/contactInfo*')) ? 'mm-active' : ''); ?>">
                    <a href="#">
                        <i class="metismenu-icon pe-7s-info"></i>
                        About
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul>
                        
                        
                        <li>
                            <a class="<?php echo e((request()->is('*dashboard/aboutcompany*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('aboutcompany.index')); ?>">
                                <i class="metismenu-icon">
                                </i>About Company
                            </a>
                        </li>
                        <li>
                            <a class="<?php echo e((request()->is('*dashboard/companyservice*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('companyservice.index')); ?>">
                                <i class="metismenu-icon   pe-7s-tools">
                                </i>  Services
                            </a>
                        </li>
                        
                        <li>
                            <a class="<?php echo e((request()->is('*dashboard/contactInfo*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('contactInfo.index')); ?>">
                                <i class="metismenu-icon pe-7s-pen"></i>
                                Contact Info
                            </a>
                        </li>
                    </ul>
                </li>

                <li >
                    <a class="<?php echo e((request()->is('*dashboard/contactus*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('contactus.index')); ?>">
                        <i class="metismenu-icon pe-7s-call"></i>
                       ContactUs
                    </a>
                </li>

                

                <li>
                    <a class="<?php echo e((request()->is('*dashboard/blogs*')) ? 'mm-active' : ''); ?>"  href="<?php echo e(route('blogs.index')); ?>">
                        <i class="metismenu-icon pe-7s-help1"></i>
                       Offers
                    </a>
                </li>
                
                <li>
                    <a class="<?php echo e((request()->is('*dashboard/sliders*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('sliders.index')); ?>">
                        <i class="metismenu-icon  pe-7s-photo-gallery"></i>
                        Slider
                    </a>
                </li>
                <li>
                    <a class="<?php echo e((request()->is('*dashboard/clientreview*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('clientreview.index')); ?>">
                        <i class="metismenu-icon  pe-7s-comment"></i>
                        Client Reviews
                    </a>
                </li>

                <li class="app-sidebar__heading">Setting</li>
                <li>
                    <a class="<?php echo e((request()->is('*dashboard/admin*')) ? 'mm-active' : ''); ?>" href="<?php echo e(route('admin.index')); ?>">
                        <i class="metismenu-icon pe-7s-users"></i>
                         Admins
                    </a>
                </li>




            </ul>
        </div>
    </div>
</div>

<div class="app-main__outer">

<?php /**PATH F:\Projects\Aquarat\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>