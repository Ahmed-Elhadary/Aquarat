<!-- Footer -->
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>

<footer id="footer" class=" custom-footer m-0" style="background: url('img/demos/church/footer-bg.jpg'); background-size: cover; background-color: #241b3e !important;">
    <div class="container pt-5">
        
        <div class="row justify-content-center text-center">
            <div class="col-lg-3 custom-sm-margin-bottom-1">
                <i class="fas fa-map-marker-alt  custom-icon-size-1"></i>
                <p class="custom-text-color-2 alternative-font-4 text-3-5">
                    <strong class="d-block text-color-light  text-5-5 line-height-8 mb-1">  <?php echo app('translator')->get('site.address'); ?></strong>
                   <a  style="font-size: 15px;"> <?php echo html_entity_decode( $contactInfo[$lang.'_address']); ?> </a>
                </p>
            </div>
            <div class="col-lg-4 custom-sm-margin-bottom-1">
                <i class="far fa-clock  custom-icon-size-1"></i>
                <p class="custom-text-color-2 alternative-font-4 text-3-5" >
                    <strong class="d-block text-color-light  text-5-5 line-height-8 mb-1">البريد الإلكترونى</strong>
                    <a  style="font-size: 18px;"><?php echo html_entity_decode( $contactInfo->email); ?></a>
                </p>
            </div>
            <div class="col-lg-3">
                <i class="fas fa-phone-volume  custom-icon-size-1"></i>
                <p class="alternative-font-4 text-3-5">
                    <strong class="d-block text-color-light  text-5-5 line-height-8 mb-1">ارقامنا  </strong>
                    <a class="text-decoration-none " style="font-size: 18px;">    <?php echo html_entity_decode( $contactInfo->phone); ?></a></br>
                    
                </p>
            </div>
        </div>
        <hr class="solid tall custom-hr-color-1" style="margin: 25px 0;">
        <div class="row text-center pb-4" >
            <div class="col">
                
                <p class=" text-3 text-color-light opacity-7" > © 2022 - 2023   جميع الحقوق محفوظة .</p>
            </div>
        </div>
    </div>


</footer>


<?php /**PATH F:\Projects\Aquarat\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>