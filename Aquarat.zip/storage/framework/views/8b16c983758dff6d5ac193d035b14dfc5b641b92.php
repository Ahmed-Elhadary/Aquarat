
<br><br><br>
<?php /**PATH F:\Projects\Aquarat\resources\views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>