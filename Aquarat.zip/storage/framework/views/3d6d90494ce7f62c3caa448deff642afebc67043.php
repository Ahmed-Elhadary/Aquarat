<?php $__env->startSection('title','المركز الاعلامي'); ?>
<?php $__env->startSection('content'); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>

<section class="page-header page-header-modern page-header-background page-header-background-sm parallax overlay overlay-color-dark overlay-show overlay-op-1 my-0" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="<?php echo e(asset('Images/1.jpeg')); ?>">
    <div class="container">
        <div class="row my-5">
            <div class="col-md-12 align-self-center text-center">
                <h1 class="text-9 text-color-light custom-secondary-font font-weight-bold mb-1">   خدماتنا</h1>
                <p class="text-color-light custom-secondary-font text-uppercase mb-0">  بعض خدماتنا</p>
            </div>
        </div>
    </div>
</section>

<section class="section section-no-border bg-color-light m-0">
    <div class="container">
        <div class="row justify-content-center">
            <?php $__currentLoopData = $CompanyServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CompanyService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mb-4">
                <article class="custom-post-blog">
                    <span class="thumb-info custom-thumb-info-2">
                        <span class="thumb-info-wrapper">
                            <a href="demo-church-blog-detail.html">
                                <img src="<?php echo e(asset('images/CompanyService/'.$CompanyService->image )); ?>" style="object-fit:cover; height: 250px " alt class="img-fluid" />
                            </a>
                        </span>
                        <span class="thumb-info-caption custom-box-shadow">
                            <span class="thumb-info-caption-text">
                                <h4 class="font-weight-bold mb-4">
                                    <span class="text-decoration-none custom-secondary-font text-color-dark">
                                        <?php echo e($CompanyService->ar_name); ?>

                                    </span>
                                </h4>
                                
                            </span>
                        </span>
                    </span>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Aquarat\resources\views/frontend/pages/blog.blade.php ENDPATH**/ ?>