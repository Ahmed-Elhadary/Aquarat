<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-display2 icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>MS Construction Dashboard
                    <div class="page-title-subheading">
                        Dashboard all over the site ,
                        You can change the content with ease and flexibility.
                    </div>
                </div>
            </div>
            <div class="page-title-actions">


            </div>
        </div>
    </div>

            <div class="row">
                
              <div class="col-xl-3 col-lg-6 mb-4">
                  <div class="card card-stats mb-4 mb-xl-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <h5 class="card-title text-uppercase text-muted mb-0">Admins</h5>
                          <span class="h2 card-number font-weight-bold mb-0"><?php echo e($admins->count()); ?></span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                            <i class="fa fa-users-cog"></i>
                          </div>
                        </div>
                      </div>
                      <p class="mt-3 mb-0 text-muted text-sm">
                        <a href="<?php echo e(route('admin.index')); ?>" class="text-danger mr-2"> More Details.. </a>
                      </p>
                    </div>
                  </div>
              </div>

              
              

              
              

              
              <div class="col-xl-3 col-lg-6 mb-4">
                <div class="card card-stats mb-4 mb-xl-0">
                  <div class="card-body">
                    <div class="row">
                      <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0"> Our business</h5>
                        <span class="h2 card-number font-weight-bold mb-0"><?php echo e($product->count()); ?></span>
                      </div>
                      <div class="col-auto">
                        <div class="icon icon-shape bg-success text-white rounded-circle shadow">
                          <i class="fas fa-chart-bar"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <a href="<?php echo e(route('products.index')); ?>" class="text-success mr-2"> More Details.. </a>
                    </p>
                  </div>
                </div>
              </div>

              
              

                
                

                
                

                
                <div class="col-xl-3 col-lg-6 mb-4">
                  <div class="card card-stats mb-4 mb-xl-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <h5 class="card-title text-uppercase text-muted mb-0">Messages</h5>
                          <span class="h2 card-number font-weight-bold mb-0"><?php echo e($messages->count()); ?></span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-success text-white rounded-circle shadow">
                            <i class="fa fa-comment"></i>
                          </div>
                        </div>
                      </div>
                      <p class="mt-3 mb-0 text-muted text-sm">
                        <a href="<?php echo e(route('contactus.index')); ?>" class="text-success mr-2"> More Details.. </a>
                      </p>
                    </div>
                  </div>
                </div>
            </div>

        <!-- Page content -->



</div>





    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Aquarat\resources\views/dashboard/pages/index.blade.php ENDPATH**/ ?>