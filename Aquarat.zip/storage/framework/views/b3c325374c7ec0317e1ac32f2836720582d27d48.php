<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Admin Login</title>

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/css/util.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/login/css/main.css')); ?>">
<!--===============================================================================================-->


</head>
<body>
    <div id="app">
        

        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH F:\Projects\Aquarat\resources\views/layouts/app.blade.php ENDPATH**/ ?>